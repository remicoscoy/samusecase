# beer_sam > 2023-06-27 12:01pm
https://universe.roboflow.com/test-2lq5m/beer_sam

Provided by a Roboflow user
License: CC BY 4.0

