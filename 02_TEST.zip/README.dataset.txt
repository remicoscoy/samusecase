# SAM_USECASE_TEST_SIMPLE > 2023-07-03 7:20pm
https://universe.roboflow.com/test-2lq5m/sam_usecase_test_simple

Provided by a Roboflow user
License: CC BY 4.0

